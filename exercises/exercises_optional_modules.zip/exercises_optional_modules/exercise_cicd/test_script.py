"""Unit tests for our simple script."""
from simple_script import greetings, get_platform_name, DEFAULT_GIT_SERVICE


def test_greetings():
    """Unit test for the `greetings` function."""

    assert greetings("GitHub") == "Greetings, fellow GitHub user."
    assert greetings("GitLab") == "Greetings, fellow GitLab user."


def test_get_platform_name():
    """Unit test for the `get_platform_name` function."""

    assert get_platform_name() == DEFAULT_GIT_SERVICE
