# GitHub actions tests repository

### Description

A repo for testing **GitHub Actions** and **GitLab CI/CD**.

### Useful links

* [GitHub Marketplace](https://github.com/marketplace?category=&query=&type=actions&verification=)
