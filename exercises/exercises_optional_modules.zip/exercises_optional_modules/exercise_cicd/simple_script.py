#!/usr/bin/env python3
"""A simple script to greet a GitHub/GitLab user."""

import os

DEFAULT_GIT_SERVICE = "'unknown git hosting service'"


def get_platform_name():
    """Return name of Git hosting service."""

    return os.environ.get("GIT_HOST_SERVICE", DEFAULT_GIT_SERVICE)


def greetings(git_service_name):
    """Print a greeting message to terminal."""

    return f"Greetings, fellow {git_service_name} user."


if __name__ == "__main__":
    git_service=get_platform_name()
    print(greetings(git_service))
