class class9(object):
    def func10(self, arg36, arg37):
        return 0

def func8(arg20, arg21):
    var22 = arg21 - (arg21 ^ -895208984) ^ 112
    var23 = -244136066 - (-530 ^ (arg21 + 242914202))
    var24 = -510 + arg20 | arg20 + var22
    var25 = (-934 + (var22 & -1229755488)) | var24
    var26 = (var23 + var22) | (2015211975 - var24)
    var27 = 483 - var23
    var28 = var27 + var22
    var29 = (var27 & arg21 & var22) ^ var28
    var30 = arg21 + (var25 - var27) - arg21
    var31 = var30 + (var23 + var27 & var25)
    var32 = (-163033568 | var27 | 1943218503) + var31
    var33 = arg20 | ((var29 & var32) & var32)
    var34 = var27 & arg20 + arg21
    result = (var25 + var28 | var33) + var24
    return result

def func7(arg12, arg13):
    var14 = (659 ^ arg13 - -889) - 578
    var15 = arg13 ^ 587 - -63 | arg13
    var16 = -2118372088 - var15 + arg13 - arg12
    var17 = (-168 - (arg12 + var15)) & -999
    var18 = (var16 | var15 - var17) - -790
    var19 = arg13 | (var18 - 471608205)
    var20 = (var16 & arg12 | var18) | var16
    var21 = (var16 & var14) & var20 + var18
    var22 = 1463722314 + var19 | var14 ^ var20
    var23 = arg13 | (var17 & var21 & 1609625538)
    var24 = (var20 | var15) ^ var19 ^ arg13
    var25 = (-53 - -770443091) - var17 + var21
    var26 = var23 ^ (var16 + (var18 ^ var24))
    var27 = -1437153693 | var15
    var28 = var22 + ((-728236450 & var22) + var14)
    var29 = var25 | ((var22 - var17) - var25)
    var30 = var25 & var18 + (var16 - var15)
    var31 = var27 - var16 | var19 ^ var21
    var32 = ((var15 | var25) + var23) | var26
    var33 = ((var24 - var21) ^ var21) - arg13
    var34 = (var14 + -911716737) & 122 & var20
    var35 = (var19 | var14) ^ var15
    if var25 < var25:
        var36 = var28 & var14 & var21 & -994
    else:
        var36 = var35 + arg13 + var14 & var16
    var37 = (var14 ^ var16 | var16) ^ var14
    var38 = var27 - var35 & (var20 | arg13)
    result = var19 - var30
    return result

if __name__ == "__main__":
    print 'prog_size: 0'
    print 'func_number: 2'
    print 'arg_number: 6'
    for i in xrange(25000):
        x = 5
        x = func1(x, i)
        print x,
    print 'prog_size: 2'
    print 'func_number: 4'
    print 'arg_number: 17'
    for i in xrange(25000):
        x = 5
        x = func2(x, i)
        print x,
    print 'prog_size: 5'
    print 'func_number: 11'
    print 'arg_number: 58'
    for i in xrange(25000):
        x = 5
        x = func4(x, i)
        print x,

