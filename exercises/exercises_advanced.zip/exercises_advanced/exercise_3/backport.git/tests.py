from test import unittest

def func8(arg30, arg31):
    var34 = class9()
    for var35 in xrange(44):
        var36 = var34.func10
        var36(arg31, arg30)
    if arg30 < arg31:
        var37 = (arg31 ^ (arg31 - 1508853846)) + (arg31 - arg30) & -965291022
    else:
        var37 = 882742315 | arg31 + arg30 ^ (((arg30 ^ 1697485991) & -458 + (arg31 & 2048104409) | arg31) + (arg30 - arg30)) + arg31
    var38 = 894 + arg31
    result = -749513698 & arg30 | ((var38 + 110) - arg30)
    return result


