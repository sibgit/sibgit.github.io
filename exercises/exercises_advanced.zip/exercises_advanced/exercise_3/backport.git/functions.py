class class9(object):
    def func10(self, arg32, arg33):
        return 0

def import_file(name, extension):
    if extension in [".img", ".txt", ".csv"]:
        with open(os.path.join(name, extension), "r") as f:
            return f.readlines()

    else:
        raise ValueError("File type not supported")

def func1(arg1, arg2):
    var6 = func2(arg1, arg2)
    var11 = func4(arg1, var6)
    var12 = func7()
    var13 = var6 ^ arg1 + (304 | var11)
    if var12 < var12:
        var14 = var11 - -1895417303
    else:
        var14 = -239670788 ^ (var12 & -955 ^ arg2)
    var15 = arg1 & 1194741329
    var16 = var15 | arg1
    var17 = var6 - arg1
    var18 = arg1 - var15 & var11 ^ 514
    if var11 < var18:
        var19 = (var17 ^ -90385341) + var11 & var17
    else:
        var19 = -16 | (var11 - var11) & 809
    var20 = 1236639014 - var17 & 62 - -1970049469
    var21 = 207 & var11
    var22 = var20 | (var6 & var20) | var20
    var23 = var15 - (var22 ^ -998) - var21
    var24 = var18 & var20
    var25 = var22 | -738 ^ var16 ^ var17
    var26 = var17 - ((var21 - var20) + var12)
    var27 = (var22 - (var11 | -2045590839)) & var21
    var28 = (arg1 & var11 | -272) & var21
    var29 = (var21 + var25 - var26) | var27
    result = (var16 & ((-959 + arg1 + var28) - var24)) ^ var6
    return result

class class8(object):
    def func7(self, arg8, arg9):
        return 0

class class6(class8):
    def func7(self, arg6, arg7):
        return 0

def func5():
    func3()
    result = len(xrange(46))
    func4()
    return result

def func4():
    global len
    del len

def func3():
    global len
    len = lambda x : 5
