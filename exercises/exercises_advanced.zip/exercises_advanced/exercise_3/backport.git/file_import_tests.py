import unittest

def func6(arg10, arg11):
    var39 = func7(arg10, arg11)
    var44 = func8(arg10, arg11)
    if var39 < arg11:
        var45 = (var39 - var39) - (arg10 - ((var44 - (-446909278 ^ 222 + arg11 + ((arg10 | 355) ^ var44 ^ var44) - 1006678802 - (-1645514170 | var39 ^ 1218921173 + -53 + arg10 + (arg11 | arg11)))) ^ var39) - var44) & 2110533681
    else:
        var45 = arg11 & var39 - arg11 & var39 - arg10 & arg11
    var46 = var39 + var39 | -826221859
    var47 = var39 | 122
    var48 = (((var39 ^ var46) & (arg10 ^ (1000036336 + 441423316 + arg11 & var44)) & arg10) + -746723105 - (-681 & arg11) ^ var39 & 499 & -1837792036 & (((arg11 - -1745617005 - arg11) & var47) ^ arg11)) & var47 & 489 - arg10
    var49 = var46 ^ (var48 + -871)
    result = var46 | ((var49 - (arg11 + var47) - var39 ^ var47) + (var44 + (var49 | 1723569624 + var48)))
    return result

def func8(arg40, arg41):
    var42 = 0
    for var43 in xrange(11):
        if arg40 < arg40:
            var42 += arg41 ^ var43
        else:
            var42 += var42 | var42
    return var42


class WidgetTestCase(unittest.TestCase):
    def setUp(self):
        self.widget = Widget('The widget')

    def test_default_widget_size(self):
        self.assertEqual(self.widget.size(), (50,50),
                         'incorrect default size')

    def test_widget_resize(self):
        self.widget.resize(100,150)
        self.assertEqual(self.widget.size(), (100,150),
                         'wrong size after resize')

def func7(arg12, arg13):
    var14 = (659 ^ arg13 - -889) - 578
    var15 = arg13 ^ 587 - -63 | arg13
    var16 = -2118372088 - var15 + arg13 - arg12
    var17 = (-168 - (arg12 + var15)) & -999
    var18 = (var16 | var15 - var17) - -790
    var19 = arg13 | (var18 - 471608205)
    var20 = (var16 & arg12 | var18) | var16
    var21 = (var16 & var14) & var20 + var18
    var22 = 1463722314 + var19 | var14 ^ var20
    var23 = arg13 | (var17 & var21 & 1609625538)
    var24 = (var20 | var15) ^ var19 ^ arg13
    var25 = (-53 - -770443091) - var17 + var21
    var26 = var23 ^ (var16 + (var18 ^ var24))
    var27 = -1437153693 | var15
    var28 = var22 + ((-728236450 & var22) + var14)
    var29 = var25 | ((var22 - var17) - var25)
    var30 = var25 & var18 + (var16 - var15)
    var31 = var27 - var16 | var19 ^ var21
    var32 = ((var15 | var25) + var23) | var26
    var33 = ((var24 - var21) ^ var21) - arg13
    var34 = (var14 + -911716737) & 122 & var20
    var35 = (var19 | var14) ^ var15
    if var25 < var25:
        var36 = var28 & var14 & var21 & -994
    else:
        var36 = var35 + arg13 + var14 & var16
    var37 = (var14 ^ var16 | var16) ^ var14
    var38 = var27 - var35 & (var20 | arg13)
    result = var19 - var30
    return result

def func5():
    closure = [3]
    def func4(arg7, arg8):
        closure[0] += func6(arg7, arg8)
        return closure[0]
    func = func4
    return func
var9 = func5()

def func2(arg3, arg4):
    def func3(acc, rest):
        var5 = (acc ^ 9) ^ 8
        if acc == 0:
            return var5
        else:
            result = func3(acc - 1, var5)
            return result
    result = func3(10, 0)
    return result
