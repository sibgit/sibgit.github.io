def func4(arg7, arg8):
    var9 = 0
    for var10 in range(30):
        var9 += var9 | arg7
    return var9
    
def func2(arg3, arg4):
    closure = [0]
    def func3(acc, rest):
        var5 = rest + -8
        closure[0] += var5
        if acc == 0:
            return var5
        else:
            result = func3(acc - 1, var5)
            return result
    result = func3(10, 0)
    return result
    
if __name__ == "__main__":
    print 'prog_size: 4'
    print 'func_number: 8'
    print 'arg_number: 30'
    for i in xrange(25000):
        x = 5
        x = func1(x, i)
        print x,
    print 'prog_size: 5'
    print 'func_number: 11'
    print 'arg_number: 39'
    for i in xrange(25000):
        x = 5
        x = func8(x, i)
        print x,

