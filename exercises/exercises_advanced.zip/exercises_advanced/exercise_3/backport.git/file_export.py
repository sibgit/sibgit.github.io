import os

class class10(class12):
    def func11(self, arg18, arg19):
        return 0

class class8(object):
    def func9(self, arg13, arg14):
        return 0

def func5(arg4, arg5):
    var6 = 0
    for var7 in range(8):
        if var6 < arg5:
            var6 += arg4 | var6
        else:
            var6 += arg4 ^ arg4
    return var6

def func4():
    func2()
    result = len(range(29))
    func3()
    return result

def func3():
    global len
    del len

def func2():
    global len
    len = lambda x : 0

def func6(arg9, arg10):
    def func7(acc, rest):
        var11 = 6 & acc - 6
        if acc == 0:
            return var11
        else:
            result = func7(acc - 1, var11)
            return result
    result = func7(10, 0)
    return result

if __name__ == "__main__":
    print 'prog_size: 5'
    print 'func_number: 14'
    print 'arg_number: 48'
    for i in xrange(25000):
        x = 5
        x = func1(x, i)
        print x,

