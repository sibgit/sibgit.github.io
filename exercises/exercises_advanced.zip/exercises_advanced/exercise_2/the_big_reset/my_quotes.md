# This is a file to store your favorite quotes

