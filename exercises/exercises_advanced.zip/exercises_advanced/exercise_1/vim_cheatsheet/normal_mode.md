# Normal mode command
Normal mode is the default mode of vim when opening a file.
Some useful commands in normal mode are:
* `dd`: cut (delete + copy to clipboard) entire line.
* `yy`: copy entire line to the clipboard.
* `p`: paste the copied text/line after cursor.
* `P` (`shift` + `p`): paste the copied text/line before cursor
* `u`: undo the last opperation (e.g. restore a deleted line).
* `v + arrows`: select text (it will become highlighted). Press "Esc" to clear
  the highlighting.
* `y`: copy highlighted text to the vim clipboard.
* `d`: cut (delete + copy) the highlighted text.
* `i`: enter "insert" mode.
* `o`: create a new empty line below the current line and enter "insert" mode.
* `dd`: cut (delete + copy to clipboard) entire line.
* `yy`: copy entire line to the clipboard.
