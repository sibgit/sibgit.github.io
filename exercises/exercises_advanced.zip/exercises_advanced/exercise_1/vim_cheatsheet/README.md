# This is a cheat-sheet project for the vim software

### What is vim?
Vim is a screen-oriented text editor with no graphical user interface, it works
directly in the terminal. Vim stands for "VI iMproved", since vim is heavily
based on the "vi" text editor.

### Vim modes
A key point to understand is that vim has several "modes". Each mode is meant
to accomplish a specific type of tasks.
The main 3 modes are the following:
* Normal: mode for navigation and simple edits.
* Insert: mode for inserting and modifying text
* Command: mode for operations like saving, exiting, etc.

TODO: add example how to open a file with vim


### Create a new file or open file
To open a file with vim, simply type `vim` followed by the name of the file.
If the file does not exist, vim will automatically create a new file.
```
vim my_file.txt
vim new_file.txt
```

### vim tutor
If you wish to learn more vim commands, you could try to type `vimtutor`
in the terminal.
