# Command mode
To enter command mode, one must be in normal mode and type `:`.
Some useful commands in command mode are:
* `w`: write the current state of the file to disk.
* `q`: exit vim.
* `wq`: save file and exit.
* `x!`: save file and exit (same as `wq`).
* `q!`: exit vim without saving any changes.
