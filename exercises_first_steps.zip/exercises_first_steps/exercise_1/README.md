## Overview
Strings are not glamorous, high-profile components of R, but they do
play a big role in many data cleaning and preparation tasks. The stringr
package provide a cohesive set of functions designed to make working
with strings as easy as possible. If you’re not familiar with strings,
the best place to start is the [chapter on
strings](http://r4ds.had.co.nz/strings.html) in R for Data Science.

Authors: MISSING
URL: MISSING
